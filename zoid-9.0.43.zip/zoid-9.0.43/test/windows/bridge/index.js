/* @flow */

import { setup } from 'post-robot/src';

setup();
