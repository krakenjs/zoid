/* @flow */

// eslint-disable-next-line import/no-namespace
import * as zoid from '../src/index';

window.zoid = zoid;
