/* @flow */

// eslint-disable-next-line import/no-commonjs
module.exports = {
    extends: 'grumbler-scripts/config/.babelrc-browser'
};
