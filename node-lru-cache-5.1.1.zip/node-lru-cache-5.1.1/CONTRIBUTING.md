Please consider signing [the neveragain.tech pledge](http://neveragain.tech/)
