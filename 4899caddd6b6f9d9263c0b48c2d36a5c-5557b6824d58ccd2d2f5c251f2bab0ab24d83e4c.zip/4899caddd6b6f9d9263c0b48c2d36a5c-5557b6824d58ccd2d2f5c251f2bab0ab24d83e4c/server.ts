import { serve } from "https://deno.land/std@0.53.0/http/server.ts";

const s = serve({ port: 8000 });
console.log("http://localhost:8000/");
let i = 0;
let reports: Map<string, boolean> = new Map();
let id: number = 0;
for await (const req of s) {
  console.log(`${req.method} ${req.url}`);
  req.headers.forEach((v, k) => {
    console.log(`${k}: ${v}`);
  });
  switch (req.url) {
    case "/report/generate":
      let trackId = id.toString();
      id += 1;

      reports.set(trackId, false);

      let delay: number = Math.round(Math.random() * 20);

      console.log(`long running report ${trackId} requires ${delay} seconds to finish... `);

      setTimeout(() => {
        reports.set(trackId, true);
        console.log(`report ${trackId} is ready`);
      }, delay * 1000);

      let headers = new Headers();
      headers.set("Location", `/poll/${trackId}`);
      req.respond({ status: 303, headers }); // we trigger here redirect right now and use 303 to clear body (next would be GET instead of POST)

      break;
    default:
      let m: any = /\/poll\/(\d+)/.exec(req.url);
      if ((m?.length || 0) > 0) {
        let trackId = m[1];
        if (reports.get(trackId)) {
          let headers = new Headers();
          headers.set("Location", `/download/${trackId}`);
          req.respond({ status: 301, headers });
        } else {
          let headers = new Headers();
          headers.set("Retry-After", "5");

          // we are using 429 here, but actually we need to use 301. but no clients support this correctly, curl support only 429
          req.respond({ status: 429, headers });
        }
      } else {
        m = /\/download\/(\d+)/.exec(req.url);
        if ((m?.length || 0) > 0) {
          let trackId = m[1];
          if (reports.get(trackId)) {
            req.respond({ body: "Hello, world!" });
          } else {
            req.respond({ status: 404 });
          }
        }
      }
      break;
  }
}
