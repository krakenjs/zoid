module.exports = {
    'rules': {
        'no-restricted-globals': [ 'error' ],
        'promise/no-native': 'off'
    }
}
