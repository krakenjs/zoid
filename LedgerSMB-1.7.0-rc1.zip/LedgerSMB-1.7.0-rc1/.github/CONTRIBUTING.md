
There's a [Community Guide](https://ledgersmb.org/community-guide) on
our site to help you contribute to our community -- be it as a user, tester,
translator or developer: your contributions are most welcome!


On behalf of the LedgerSMB Core project team,
Erik Huelsmann



