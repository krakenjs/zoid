
The LedgerSMB project follows the [Ubuntu code of
conduct](https://www.ubuntu.com/about/about-ubuntu/conduct).

Thank you for taking notice,


On behalf of the LedgerSMB project Core team,
Erik Huelsmann

