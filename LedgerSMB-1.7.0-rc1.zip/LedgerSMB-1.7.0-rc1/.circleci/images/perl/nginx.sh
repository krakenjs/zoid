#!/bin/bash -x

/usr/sbin/nginx -g 'daemon off;' -c /etc/nginx/nginx.conf
