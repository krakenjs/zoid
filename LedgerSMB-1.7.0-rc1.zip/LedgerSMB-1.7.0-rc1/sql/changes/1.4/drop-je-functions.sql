DROP FUNCTION IF EXISTS je_get_default_lines();
DROP FUNCTION IF EXISTS je_set_default_lines(integer);
