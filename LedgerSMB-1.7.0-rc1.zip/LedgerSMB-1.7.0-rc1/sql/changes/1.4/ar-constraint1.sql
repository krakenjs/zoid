
ALTER TABLE ar ADD COLUMN is_return bool default false;
