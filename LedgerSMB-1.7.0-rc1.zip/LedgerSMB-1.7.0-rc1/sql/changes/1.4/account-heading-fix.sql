ALTER TABLE account_heading ADD COLUMN category CHAR(1);
