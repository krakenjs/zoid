ALTER TABLE ar ADD setting_sequence TEXT;
