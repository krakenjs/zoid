
update asset_dep_method
   set sproc = 'asset_dep_straight_line_month'
 where sproc = 'asset_dep_straight_line_whl_m';

