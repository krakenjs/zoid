alter table partscustomer add qty numeric default 0;
