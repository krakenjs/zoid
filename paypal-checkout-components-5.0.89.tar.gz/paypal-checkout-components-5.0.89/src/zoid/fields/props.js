/* @flow */

export type FieldsProps = {|
    nonce : ?string
|};
