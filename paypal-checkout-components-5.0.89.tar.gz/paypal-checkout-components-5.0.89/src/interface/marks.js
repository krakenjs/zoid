/* @flow */

import { getMarksComponent } from '../marks/component';

export const Marks = {
    __get__: () => getMarksComponent()
};
