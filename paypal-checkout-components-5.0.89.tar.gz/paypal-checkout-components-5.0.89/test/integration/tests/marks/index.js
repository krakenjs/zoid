/* @flow */

import './standalone';
